for(let i =1; i <= 150; i++){
 let precocusto = parseFloat(prompt('Digite o preço de custo do produto'))
 let precovenda = parseFloat(prompt('Digite o preço de venda do produto'))
 let tipo = prompt('Digite o tipo de produto')
 console.log('preço de custo: '+ precocusto)
 console.log('preço de venda:' + precovenda)
 console.log(tipo)
 }