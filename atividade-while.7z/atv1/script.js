for(let i =1; i <= 3; i++){
    let nota = parseFloat(prompt('Digite a sua primeira nota'))
    let nota2 = parseFloat(prompt('Digite a segunda nota'))
    let media = parseFloat(nota + nota2)/2
    console.log('sua média é:'+ media)
    alert(media)
}