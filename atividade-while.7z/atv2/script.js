for(let i =1; i <= 5; i++){
    let produto = parseFloat(prompt('Digite o preço do seu produto'))
    let quantidade = parseFloat(prompt('Digite a quantidade do produto'))
    let preço = parseFloat(produto * quantidade)
    console.log('o produto custou: ' + preço)
    if(preço > 100){
        console.log('Este produto custou mais de 100 reais')
    }for(let preço =
         0; preço <= 1; preço++){
        console.log(preço)
    }
}