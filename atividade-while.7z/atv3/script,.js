for(let i =1; i <= 10; i++){
   let numero = parseInt(prompt('Digite o número'))
   console.log(numero)
   if(numero > 0){
    console.log('maior que 0')
    console.log('o dobro desse numero positivo é: ' + numero*2)
   }else{
    console.log('menor que 0')
   }
}